
package bookshopmanagementsystem;

import java.sql.Date;

/**
 *
 * @author Adelya Destriana Putri
 */

//Kelas customerData ini juga merupakan kelas Java yang digunakan untuk merepresentasikan data pelanggan atau transaksi pelanggan terkait dengan pembelian buku dalam suatu aplikasi. Berikut adalah penjelasan atribut dan metode-metode dalam kelas ini:
public class customerData {
    
    private Integer customerId;
    private Integer bookId;
    private String title;
    private String author;
    private String genre;
    private Integer quantity;
    private Double price;
    private Date date;
    
    //Konstruktor ini digunakan untuk membuat objek customerData dengan menginisialisasi nilai atribut-atributnya sesuai dengan parameter yang diberikan.
    public customerData(Integer customerId, Integer bookId, String title, String author
            , String genre, Integer quantity, Double price, Date date){
        this.customerId = customerId;
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.quantity = quantity;
        this.price = price;
        this.date = date;
    }
    
    //Metode-metode ini digunakan untuk mendapatkan nilai dari masing-masing atribut. Metode-metode ini bersifat pembacaan (getter) dan memberikan akses publik untuk membaca nilai atribut secara aman.
    public Integer getCustomerId(){
        return customerId;
    }
    public Integer getBookId(){
        return bookId;
    }
    public String getTitle(){
        return title;
    }
    public String getAuthor(){
        return author;
    }
    public String getGenre(){
        return genre;
    }
    public Integer getQuantity(){
        return quantity;
    }
    public Double getPrice(){
        return price;
    }
    public Date getDate(){
        return date;
    }
    
}
