package bookshopmanagementsystem;

import java.sql.Date;

/**
 *
 * @Author     : Adelya Destriana Putri
 */

//Kelas bookData ini merupakan kelas Java yang digunakan untuk merepresentasikan data buku dalam suatu aplikasi. Berikut adalah penjelasan tentang atribut dan metode-metode dalam kelas ini:
public class bookData {
    
    private Integer bookId; //menyimpan ID unik untuk buku
    private String title; //menyimpan judul buku
    private String author; //menyimpan nama penulis buku
    private String genre; //menyimpan genre atau kategori buku
    private Date date; //menyimpan tanggal terbit buku
    private Double price; //menyimpan harga buku
    private String image; //menyimpan path atau URL gambar buku

    //Konstruktor ini digunakan untuk membuat objek bookData dengan menginisialisasi nilai atribut-atributnya sesuai dengan parameter yang diberikan.
    public bookData(Integer bookId, String title, String author, String genre
            , Date date, Double price, String image){
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.date = date;
        this.price = price;
        this.image = image;
    }
    
    //metode getters, Metode-metode ini digunakan untuk mendapatkan nilai dari masing-masing atribut. Metode-metode ini bersifat pembacaan (getter) dan memberikan akses publik untuk membaca nilai atribut secara aman.
    public Integer getBookId(){
        return bookId;
    }
    public String getTitle(){
        return title;
    }
    public String getAuthor(){
        return author;
    }
    public String getGenre(){
        return genre;
    }
    public Date getDate(){
        return date;
    }
    public Double getPrice(){
        return price;
    }
    public String getImage(){
        return image;
    }
    
}
