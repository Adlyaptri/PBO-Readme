
package bookshopmanagementsystem;

/**
 *
 * @Author     : Adelya Destriana Putri
 */
public class getData {
    
    public static String username;
    public static String path;
    
}
