/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.adelyadestrianaputri;

/**
 *
 * @author Adelya Destriana Putri
 */
public class AdelyaDestrianaPutri {
    public static void main(String[] args) {
        System.out.println("Created by_22343033_Adelya Destriana Putri");
        System.out.println("Welcome to Java Programming Adelya Destriana Putri!!!");
        System.out.println("Welcome to Java Programming Adelya Destriana Putri!!!");
    }
}
