/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.thetree;

/**
 *
 * @author Adelya Destriana Putri
 */
public class TheTree {
    public static void main(String[] agrs) {
        System.out.println("Created by_22343033_Adelya Destriana Putri");        
        System.out.println("I thing that I shall never see,");
        System.out.println("a poem as lovely as a tree.");
        System.out.println("A tree whose hungry mouth is pressed");
        System.out.println("Against the Earth's sweet flowing breast.");
    }
    
}
