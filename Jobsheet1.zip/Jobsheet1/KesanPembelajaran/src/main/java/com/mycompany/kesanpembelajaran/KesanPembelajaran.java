/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.kesanpembelajaran;

/**
 *
 * @author Adelya Destriana Putri
 */
public class KesanPembelajaran {
    public static void main(String[] args) {
        System.out.println("Created by_22343033_Adelya Destriana Putri");
        System.out.println("Kesan pertama saya dalam perkuliahan OOP atau Object Oriented Programming ini yaitu menyenangkan karna disini saya mendapat ilmu baru yang dimana saya sebelumnya belum mengetahui aplikasi netbeans yang berguna untuk menjalankan program dalam bahasa Java ini"); 
        System.out.println("Kemudian melalui mata kuliah ini saya bisa mengetahui aplikasi ini dan bisa menggunakanya dan menjalankan project dengan baik dan benar, dengan adanya aplikasi ini");
    }    
}

