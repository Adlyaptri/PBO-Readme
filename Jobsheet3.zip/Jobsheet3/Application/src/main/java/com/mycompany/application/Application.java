/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.application;

/**
 *
 * Created by_22343033_Adelya Destriana Putri
 */
public class Application {

    public static void main(String[] args) {
         int myNumber = 88;
         short myShort = 847;
         long myLong = 9797L;
         double myDouble = 72.97d;
         float myFloat = 324.3f;
         char myChar = 'y';
         boolean myBoolean = false;
         byte myByte = 127;
        System.out.println("myNumber");
        System.out.println("myShort");
        System.out.println("myLong");
        System.out.println("myDouble");
        System.out.println("myFloat");
        System.out.println("myChar");
        System.out.println("myBoolean");
        System.out.println("myByte");        
    }
}
