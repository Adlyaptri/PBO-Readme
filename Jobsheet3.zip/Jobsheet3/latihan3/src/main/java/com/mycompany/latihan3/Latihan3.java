/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.latihan3;

/**
 *
 * Created_22343033_Adelya Destriana Putri
 */
public class Latihan3 {

    public static void main(String[] args) {
         int value = 10;
         char x = 'A';
         
        System.out.println("value");
        System.out.println("The value of x=" + x);
    }
}
