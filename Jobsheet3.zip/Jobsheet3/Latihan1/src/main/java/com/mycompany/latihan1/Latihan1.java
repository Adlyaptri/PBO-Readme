/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.latihan1;

/**
 *
 * Created by_22343033_Adelya Destriana Putri
 */
public class Latihan1 {
    public static void main(String[] args) {
         int a = 10;
         short s = 2;
         byte b = 6;
         long l = 1253621332231L;
         float f = 65.20298f;
         double d = 876.765d;
        System.out.println("The integer variable is" + a);
        System.out.println("The short variable is" + s);
        System.out.println("The byte variable is" + b);
        System.out.println("The long variable is" + l);
        System.out.println("The float variable is" + f);
        System.out.println("The double variable is" + d);        
    }
}
