/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tugas;

/**
 *
 * Created by_22343033_Adelya Destriana Putri
 */
public class Tugas {

    public static void main(String[] args) {
         int a = 10;
         char Number = 'a';
         boolean letter = true;
         String str = "hello";
        System.out.println("Number");
        System.out.println("letter");
        System.out.println("result");       
    }
}
