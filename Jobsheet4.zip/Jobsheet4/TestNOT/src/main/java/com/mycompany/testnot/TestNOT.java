/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.testnot;

/**
 *
 * @author user
 */
public class TestNOT {

    public static void main(String[] args) {
        boolean val1 = true;
        boolean val2 = false;
        
        System.out.println(!val1);
        System.out.println(!val2);
    }
}
