/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package satudua;

/**
 *
 * @author user
 */
public class RataRata {

    public static void main(String[] args) {
        //mendafinisikan tiga angka
        int angka1 = 10;
        int angka2 = 20;
        int angka3 = 45;
        
        //menghitung nilai rata-rata
        double RataRata = (angka1 + angka2 + angka3) / 3.0;
        
        //menampilkan hasil rata-rata
        System.out.println("Nilai rata-rata dari " + angka1 + ", " + angka2 + ", dan " + angka3 + " adalah: " + RataRata);
    }
}
