/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.kondisioperator1;

/**
 *
 * @author user
 */
public class KondisiOperator1 {

    public static void main(String[] args) {
        int score = 0;
        char answer = 'a';
        
        score = (answer == 'b') ? 10 : 0;
        System.out.println("Score = " + score);
    }
}
