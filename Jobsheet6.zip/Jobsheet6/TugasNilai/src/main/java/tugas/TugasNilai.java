/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package tugas;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class TugasNilai {

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        double total = 0;
        for (int i = 1; i <= 3; i++) {
            System.out.print("Masukkan nilai ujian ke-" + i + ": ");
            double nilai = Double.parseDouble(reader.readLine());
            total += nilai;
        }

        double rataRata = total / 3;

        System.out.println("Rata-rata nilai: " + rataRata);
        if (rataRata >= 60) {
            System.out.println(":-)");
        } else {
            System.out.println(":-(");
        }
    }
}
