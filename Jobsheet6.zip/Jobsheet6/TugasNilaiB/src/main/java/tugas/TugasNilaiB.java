/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package tugas;

import javax.swing.JOptionPane;

public class TugasNilaiB {
    public static void main(String[] args) {
        double total = 0;
        for (int i = 1; i <= 3; i++) {
            String input = JOptionPane.showInputDialog("Masukkan nilai ujian ke-" + i + ": ");
            double nilai = Double.parseDouble(input);
            total += nilai;
        }

        double rataRata = total / 3;

        String output = "Rata-rata nilai: " + rataRata + "\n";
        if (rataRata >= 60) {
            output += ":-)";
        } else {
            output += ":-(";
        }

        JOptionPane.showMessageDialog(null, output);
    }
}
