/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tugas2mahasiswa;

/**
 *
 * @author Adelya Destriana Putri
 */
class Mahasiswa {
    // Atribut
    String nama;
    int nim;
    String semester;
    double ip;

    // Konstruktor
    public Mahasiswa(String nama, int nim, String semester, double ip) {
        this.nama = nama;
        this.nim = nim;
        this.semester = semester;
        this.ip = ip;
    }

    // Metode untuk menentukan jumlah SKS yang dapat diambil
    public int hitungSKS() {
        int sks = 0;
        if (ip >= 3.5) {
            sks = 24;
        } else if (ip >= 3.0) {
            sks = 22;
        } else if (ip >= 2.5) {
            sks = 20;
        } else if (ip >= 2.0) {
            sks = 18;
        } else {
            sks = 15;
        }
        return sks;
    }

    // Metode untuk menampilkan informasi mahasiswa
    public void tampilkanInfo() {
        System.out.println("Nama Mahasiswa: " + nama);
        System.out.println("NIM: " + nim);
        System.out.println("Semester: " + semester);
        System.out.println("IP Semester ini: " + ip);
        System.out.println("Anda berhak mengontrak " + hitungSKS() + " SKS pada Semester " + semester);
    }
}

public class Tugas2Mahasiswa {
    public static void main(String[] args) {
        // Membuat objek Mahasiswa
        Mahasiswa joni = new Mahasiswa("Joni", 12345, "V", 3.50);

        // Menampilkan informasi mahasiswa dan jumlah SKS yang dapat diambil
        joni.tampilkanInfo();
    }
}
