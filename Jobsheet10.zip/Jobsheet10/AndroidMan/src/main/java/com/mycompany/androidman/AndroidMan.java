/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.androidman;

/**
 *
 * @author user
 */
public class AndroidMan {

    public static void main(String[] args) {
        // Membuat objek Android
        Android androidPhone = new Android();

        // Memanggil empat metode pada objek Android
        androidPhone.nyala();
        androidPhone.panggilan();
        androidPhone.sms();
        androidPhone.shutdown();
    }
}

