/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.androidman;

/**
 *
 * @author user
 */
public class Android {
    
    // Metode untuk menyalakan ponsel Android
    public void nyala() {
        System.out.println("Android menyala");
    }

    // Metode untuk melakukan panggilan telepon
    public void panggilan() {
        System.out.println("Kring Kring Kring, ada panggilan masuk");
    }

    // Metode untuk mengirim SMS
    public void sms() {
        System.out.println("Tenenoeeett, ada SMS baru");
    }

    // Metode untuk mematikan ponsel Android
    public void shutdown() {
        System.out.println("Android dimatikan");
    }
}
