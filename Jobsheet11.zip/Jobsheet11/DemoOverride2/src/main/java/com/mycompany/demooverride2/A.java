/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.demooverride2;

/**
 *
 * @author Adelya Destriana Putri
 */
public class A {
    private int a;

    public void setA(int nilai){
        a = nilai;        
    }
    
    public int getA(){
        return a;
    }
    
    public void tampilkanNilai(){
        System.out.println("Nilai a = " + getA());
    }
}
