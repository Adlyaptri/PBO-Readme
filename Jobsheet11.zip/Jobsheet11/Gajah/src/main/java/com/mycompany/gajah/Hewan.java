/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gajah;

/**
 *
 * @author Adelya Destriana Putri
 */
public class Hewan {
    public static void testClassMethod(){
        System.out.println("TheClass Method in Hewan");
    }
    
    public void testInstanceMethod(){
        System.out.println("The Instance Method in Hewan");
    }
}
