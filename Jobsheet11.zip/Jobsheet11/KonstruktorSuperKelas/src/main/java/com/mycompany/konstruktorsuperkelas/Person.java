/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.konstruktorsuperkelas;

/**
 *
 * @author user
 */
public class Person {
    protected String name;
    protected int age;
    
    public Person(String name, int age){
        this.name = name;
        this.age = age;
    }
    
    //metode
    public void info(){
        System.out.println("Name : " + this.name);
        System.out.println("Usia : " + this.age);
    }
    //alhir kelas Program
}
