/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.konstruktorsuperkelas;

/**
 *
 * @author Adelya Destriana Putri
 */
public class KonstruktorSuperKelas {

    public static void main(String[] args) {
        Employ programer1 = new Employ("12345678", "Budi", 33);
        programer1.info();
    }
}
