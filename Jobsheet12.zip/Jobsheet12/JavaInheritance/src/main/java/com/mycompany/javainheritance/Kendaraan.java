/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.javainheritance;

/**
 *
 * @author Adelya Destriana Putri
 */
public class Kendaraan {
    double hargaDasar = 1000000;
    public void tampilkanHarga()
    {
        System.out.println("Harga kendaraan adalah Rp." + hargaDasar);
    }
}
