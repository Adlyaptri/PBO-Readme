package com.mycompany.polymorphismstatic;

/**
 *
 * author Adelya Destriana Putri
 */
public class PolymorphismStatic {

    public static void main(String[] args) {
        // Memanggil metode keliling dari kelas CompileTime untuk persegi
        System.out.println("Sisi Persegi adalah: 4\nKeliling Persegi adalah: " + CompileTime.keliling(4) + "\n");

        // Memanggil metode keliling dari kelas CompileTime untuk persegi panjang
        System.out.println("Sisi Persegi Panjang adalah: 10, 15\nKeliling Persegi Panjang adalah: " + CompileTime.keliling(10, 15));
    }
}
