/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aktivitasutama;

/**
 *
 * @author Adelya Destriana Putri
 */
public class AktivitasUtama {

    public static void main(String[] args) {
        AktivitasPagiAnak a1 = new AktivitasPagiAnak();
        
        //panggil method anak umur 1 tahun
        a1.lari();
        a1.berenang();
    }
}
