/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package satutiga.scanner1;

import java.util.Scanner;

/**
 *
 * @author user
 */
public class Scanner1 {

    public static void main(String[] args) {
        Scanner in = new Scanner (System.in);
        
        System.out.print("Masukan nama lengkap: ");
        String nama = in.nextLine();
        
        System.out.println("Masukan NIM: ");
        int NIM = in.nextInt();
        
        System.out.println("Masukan Nilai: ");
        float nilai = in.nextFloat();
        
        System.out.println("\nNama : " + nama +
                           "\nNIM : " + NIM +
                           "\nNilai : " + nilai);
    }
}
