/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package satudua;

/**
 *
 * AdelyaDestrianaPutri
 */
import java.util.Scanner;

public class TugasInputScanner {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Masukan Kata1: ");
        String Kata1 = scanner.next();

        System.out.print("Masukan Kata2: ");
        String Kata2 = scanner.next();

        System.out.print("Masukan Kata3: ");
        String Kata3 = scanner.next();

        System.out.println(Kata1 + " " + Kata2 + " " + Kata3);

        scanner.close();
    }
}

