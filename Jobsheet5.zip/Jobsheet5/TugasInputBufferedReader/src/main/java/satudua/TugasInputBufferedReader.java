/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package satudua;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class TugasInputBufferedReader {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        System.out.print("Masukan Kata1: ");
        String Kata1 = reader.readLine();

        System.out.print("Masukan Kata2: ");
        String Kata2 = reader.readLine();

        System.out.print("Masukan Kata3: ");
        String Kata3 = reader.readLine();

        System.out.println(Kata1 + " " + Kata2 + " " + Kata3);

        reader.close();
    }
}
