/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.casesensitive;

/**
 *
 * Created by_22343033_Adelya Destriana Putri
 */
public class CaseSensitive {

    public static void main(String[] args) {
        String nama = "Petani Kode";
        String Nama = "petanikode";
        String NAMA = "Petanikode.com";
        
        System.out.println("nama");
        System.out.println("Nama");
        System.out.println("NAMA");
    }
}
