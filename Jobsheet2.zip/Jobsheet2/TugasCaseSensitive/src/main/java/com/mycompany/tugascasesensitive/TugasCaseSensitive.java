/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tugascasesensitive;

/**
 *
 * @author Adelya Destriana Putri
 */
public class TugasCaseSensitive {

    public static void main(String[] args) {        
        String nama = "Adelya Destriana Putri";
        String prodi = "Informatika";
        
        System.out.println("Saya, " + nama);
        System.out.println("Mahasiswa Universitas Negeri Padang dengan prodi " + prodi);        
    }
}
