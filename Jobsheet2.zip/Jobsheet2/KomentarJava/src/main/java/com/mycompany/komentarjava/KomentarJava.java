/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.komentarjava;

/**
 *
 * Created by_22343033_Adelya Destriana Putri
 */
public class KomentarJava {

    public static void main(String[] args) {
        System.out.println("Single line comment above");
        // Comment line 1
        System.out.println("Multi line comments below");
        /*Comment line 2
          Comment line 3
          Comment line 4
        */
    }
}
