/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package satulima;

/**
 *
 * @author Adelya Destriana Putri
 */
public class ArraySimple {

    public static void main(String[] args) {
        int[] ages = new int[100];
        for (int i = 0; i < 100; i++) { // Hapus titik koma (;) dan tambahkan kurung kurawal {}
            System.out.println(ages[i]);
        }
    }
}

