/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package satutujuh;

public class DaysOfWeek {
    public static void main(String[] args) {
        String days[] = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
        
        // Mencetak semua nilai dalam array menggunakan for-loop
        for (int i = 0; i < days.length; i++) {
            System.out.println(days[i]);
        }
    }
}
