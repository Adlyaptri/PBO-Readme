/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package satulima;

/**
 *
 * @author Adelya Destriana Putri
 */
public class ArraySample3 {

    public static void main(String[] args) {
        
        //String array 4 baris x 2 kolom
        String[][] dogs = {{"Terry", "brown"}, //baris ke 0
                           {"Kristin", "white"}, //baris ke-1
                           {"Toby", "gray",}, //baris ke-2
                           {"Fido", "black"}, //baris ke-3
                          };
        System.out.println(dogs[0][0]);
        //mengakises variabel dogs dengan indeks baris 0, indeks kolom 0
    }
}
