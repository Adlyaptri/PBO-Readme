/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package satutujuh;

import javax.swing.JOptionPane;

public class NomorTerbesar {
    public static void main(String[] args) {
        int[] nomor = new int[10]; // Membuat array untuk menyimpan 10 nomor

        // Meminta pengguna untuk memasukkan 10 nomor
        for (int i = 0; i < 10; i++) {
            String input = JOptionPane.showInputDialog("Masukkan nomor ke-" + (i + 1) + ":");
            try {
                nomor[i] = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Input tidak valid. Masukkan angka.");
                i--; // Jika input tidak valid, kurangi indeks i agar pengguna memasukkan ulang nomor tersebut.
            }
        }

        int nomorTerbesar = nomor[0]; // Inisialisasi dengan nomor pertama dalam array

        // Mencari nomor terbesar dalam array
        for (int i = 1; i < nomor.length; i++) {
            if (nomor[i] > nomorTerbesar) {
                nomorTerbesar = nomor[i];
            }
        }

        // Menampilkan nomor terbesar kepada pengguna
        JOptionPane.showMessageDialog(null, "Nomor terbesar yang Anda masukkan adalah: " + nomorTerbesar);
    }
}
