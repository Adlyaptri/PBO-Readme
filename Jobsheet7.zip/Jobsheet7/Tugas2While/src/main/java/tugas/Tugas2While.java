/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package tugas;


public class Tugas2While {
        public static void main(String[] args) {
            int i = 100;
            while (i >= 1) {
            System.out.println(i);
            i--;
            }
        }
    }