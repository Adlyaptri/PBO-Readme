/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package tugas;

public class Tugas1For {
    public static void main(String[] args){
        for (int i=1; i<=100; i++){
            System.out.println("Adelya Destriana Putri");
        }
    }
}
