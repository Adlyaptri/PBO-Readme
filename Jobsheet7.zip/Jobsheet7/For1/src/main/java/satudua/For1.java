/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package satudua;

/**
 *
 * Adelya Destriana Putri
 */
public class For1 {

    public static void main(String[] args) {
        int bilangan;
        for (bilangan = 60 ; bilangan >= 10; bilangan -= 10)
        System.out.println(bilangan);
    }
}
