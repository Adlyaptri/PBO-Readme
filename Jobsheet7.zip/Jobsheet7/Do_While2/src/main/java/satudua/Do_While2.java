/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package satudua;

/**
 *
 * @author user
 */
public class Do_While2 {

    public static void main(String[] args) {
        int i = 0;
        
        do
        {
            System.out.println(i);
            i += 10;
        }
        while (i <= 100);
    }
}
