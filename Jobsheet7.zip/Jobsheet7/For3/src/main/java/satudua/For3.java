/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package satudua;

/**
 *
 * @author Adelya Destriana Putri
 */
public class For3 {

    public static void main(String[] args) {
        int bil;
        for (bil = 0 ; bil <= 10; bil++)
            System.out.println(bil);
    }
}
