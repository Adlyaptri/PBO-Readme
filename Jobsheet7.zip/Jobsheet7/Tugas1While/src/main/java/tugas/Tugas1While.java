/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package tugas;

public class Tugas1While {
    public static void main(String[] args){
         int i = 1;
         
         while (i <= 100){
             System.out.println("Adelya Destriana Putri Informatika");
             i++;
         }
    }
}
