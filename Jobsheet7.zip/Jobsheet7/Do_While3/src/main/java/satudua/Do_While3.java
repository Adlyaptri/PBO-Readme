/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package satudua;

/**
 *
 * @author Adelya Destriana Putri
 */
public class Do_While3 {

    public static void main(String[] args) {
        int i = 20;
        
        do
        {
            System.out.println(i);
            i++;
        }
        while (i < 10);
    }
}
