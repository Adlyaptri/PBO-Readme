/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package tugas;

public class Tugas2For {
    public static void main(String[] args) {
        for (int i = 100; i >= 1; i--) {
            System.out.println(i);
        }
    }
}
